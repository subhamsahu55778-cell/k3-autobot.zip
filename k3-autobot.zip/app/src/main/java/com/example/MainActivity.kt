package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.service.OverlayService
import com.example.ui.ConfigScreen
import com.example.ui.ConfigViewModel
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private val viewModel: ConfigViewModel by viewModels()

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) {
        launchOverlayAndMinimize()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val uiState by viewModel.uiState.collectAsStateWithLifecycle()
            val telemetry by viewModel.telemetry.collectAsStateWithLifecycle()

            LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
                viewModel.refreshPermissions()
            }

            MyApplicationTheme {
                ConfigScreen(
                    uiState = uiState,
                    telemetry = telemetry,
                    onOpenAccessibilitySettings = { openAccessibilitySettings() },
                    onOpenOverlaySettings = { openOverlayPermissionSettings() },
                    onSelectTarget = viewModel::selectTarget,
                    onQuickFillBaseChanged = viewModel::updateQuickFillBase,
                    onSelectQuickFillMultiplier = viewModel::selectQuickFillMultiplier,
                    onApplyQuickFill = viewModel::applyQuickFill,
                    onLevelInputChanged = viewModel::updateLevelInput,
                    onSaveConfiguration = {
                        viewModel.saveConfiguration()
                    },
                    onLaunchOverlay = { handleLaunchOverlayRequest() },
                )
            }
        }
    }

    private fun openAccessibilitySettings() {
        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }

    private fun openOverlayPermissionSettings() {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName"),
        )
        startActivity(intent)
    }

    private fun handleLaunchOverlayRequest() {
        if (!viewModel.saveConfiguration()) return

        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(
                this,
                "Please grant Display Over Other Apps permission first.",
                Toast.LENGTH_SHORT,
            ).show()
            openOverlayPermissionSettings()
            return
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            return
        }

        launchOverlayAndMinimize()
    }

    private fun launchOverlayAndMinimize() {
        OverlayService.start(this)
        moveTaskToBack(true)
    }
}

package com.example.model

enum class BetTarget(val label: String, val buttonLabel: String) {
    BIG("Big", "Big 2X"),
    SMALL("Small", "Small 2X");

    fun toggled(): BetTarget = if (this == BIG) SMALL else BIG
}

enum class BotStatus(val displayLabel: String, val isTerminalError: Boolean = false) {
    IDLE("IDLE"),
    WAITING_FOR_NEXT_ROUND("WAITING FOR NEXT ROUND"),
    PLACING_BET("PLACING BET"),
    VERIFYING_RESULT("VERIFYING RESULT"),
    STOPPED_LEVEL_15_LIMIT("STOPPED - LEVEL 15 LIMIT REACHED", isTerminalError = true),
    STOPPED_UI_ERROR("STOPPED - UI ERROR", isTerminalError = true);

    val isRunning: Boolean
        get() = this == WAITING_FOR_NEXT_ROUND || this == PLACING_BET || this == VERIFYING_RESULT
}

data class BotConfig(
    val target: BetTarget = BetTarget.BIG,
    val levelAmounts: List<Int> = defaultLevelAmounts(),
    val quickFillBase: Int = 10,
    val quickFillMultiplier: Int = 2,
) {
    fun amountForLevel(level: Int): Int {
        val index = (level - 1).coerceIn(0, LEVEL_COUNT - 1)
        return levelAmounts.getOrElse(index) { 10 }.coerceAtLeast(1)
    }

    companion object {
        const val LEVEL_COUNT = 15

        fun defaultLevelAmounts(base: Int = 10, multiplier: Int = 2): List<Int> {
            val safeBase = base.coerceAtLeast(1)
            val safeMult = multiplier.coerceIn(2, 5)
            return List(LEVEL_COUNT) { index ->
                var value = safeBase.toLong()
                repeat(index) {
                    value = (value * safeMult).coerceAtMost(1_000_000L)
                }
                value.toInt()
            }
        }
    }
}

data class BotTelemetry(
    val status: BotStatus = BotStatus.IDLE,
    val currentPeriod: String = "---",
    val lastBetPeriod: String = "",
    val remainingSeconds: Int? = null,
    val currentLevel: Int = 1,
    val activeAmount: Int = 10,
    val target: BetTarget = BetTarget.BIG,
    val statusMessage: String = "Ready",
    val winsCount: Int = 0,
    val lossesCount: Int = 0,
    val isAccessibilityConnected: Boolean = false,
    val isOverlayActive: Boolean = false,
)

package com.example.data

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Rect
import com.example.model.BetTarget
import com.example.model.BotConfig
import com.example.model.BotStatus
import com.example.model.BotTelemetry
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class BotConfigRepository private constructor(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val _config = MutableStateFlow(loadConfig())
    val config: StateFlow<BotConfig> = _config.asStateFlow()

    private val _telemetry = MutableStateFlow(
        BotTelemetry(
            target = _config.value.target,
            activeAmount = _config.value.amountForLevel(1),
        )
    )
    val telemetry: StateFlow<BotTelemetry> = _telemetry.asStateFlow()

    private val _automationRequested = MutableStateFlow(false)
    val automationRequested: StateFlow<Boolean> = _automationRequested.asStateFlow()

    @Volatile
    var overlayBoundsOnScreen: Rect? = null

    private fun loadConfig(): BotConfig {
        val targetStr = prefs.getString(KEY_TARGET, BetTarget.BIG.name) ?: BetTarget.BIG.name
        val target = runCatching { BetTarget.valueOf(targetStr) }.getOrDefault(BetTarget.BIG)
        val quickBase = prefs.getInt(KEY_QUICK_BASE, 10).coerceAtLeast(1)
        val quickMult = prefs.getInt(KEY_QUICK_MULT, 2).coerceIn(2, 3)

        val defaults = BotConfig.defaultLevelAmounts(quickBase, quickMult)
        val levels = (1..BotConfig.LEVEL_COUNT).map { level ->
            prefs.getInt("$KEY_LEVEL_PREFIX$level", defaults[level - 1]).coerceAtLeast(1)
        }
        return BotConfig(
            target = target,
            levelAmounts = levels,
            quickFillBase = quickBase,
            quickFillMultiplier = quickMult,
        )
    }

    fun saveConfig(newConfig: BotConfig) {
        val sanitizedLevels = (0 until BotConfig.LEVEL_COUNT).map { i ->
            newConfig.levelAmounts.getOrElse(i) { 10 }.coerceAtLeast(1)
        }
        val sanitized = newConfig.copy(
            levelAmounts = sanitizedLevels,
            quickFillBase = newConfig.quickFillBase.coerceAtLeast(1),
            quickFillMultiplier = newConfig.quickFillMultiplier.coerceIn(2, 3),
        )
        prefs.edit().apply {
            putString(KEY_TARGET, sanitized.target.name)
            putInt(KEY_QUICK_BASE, sanitized.quickFillBase)
            putInt(KEY_QUICK_MULT, sanitized.quickFillMultiplier)
            sanitizedLevels.forEachIndexed { index, amount ->
                putInt("$KEY_LEVEL_PREFIX${index + 1}", amount)
            }
            apply()
        }
        _config.value = sanitized
        _telemetry.update { current ->
            val level = current.currentLevel.coerceIn(1, BotConfig.LEVEL_COUNT)
            current.copy(
                target = sanitized.target,
                activeAmount = sanitized.amountForLevel(level),
            )
        }
    }

    fun toggleTargetFromOverlay() {
        if (_automationRequested.value || _telemetry.value.status.isRunning) return
        val current = _config.value
        saveConfig(current.copy(target = current.target.toggled()))
    }

    fun requestStartAutomation() {
        val cfg = _config.value
        _telemetry.update {
            it.copy(
                status = BotStatus.WAITING_FOR_NEXT_ROUND,
                currentLevel = 1,
                activeAmount = cfg.amountForLevel(1),
                target = cfg.target,
                lastBetPeriod = "",
                statusMessage = "Scanning K3 screen...",
                winsCount = 0,
                lossesCount = 0,
            )
        }
        _automationRequested.value = true
    }

    fun requestStopAutomation(
        status: BotStatus = BotStatus.IDLE,
        message: String = "Stopped by user",
    ) {
        _automationRequested.value = false
        _telemetry.update {
            it.copy(
                status = status,
                statusMessage = message,
            )
        }
    }

    fun updateTelemetry(transform: (BotTelemetry) -> BotTelemetry) {
        _telemetry.update(transform)
    }

    fun setAccessibilityConnected(connected: Boolean) {
        _telemetry.update { it.copy(isAccessibilityConnected = connected) }
    }

    fun setOverlayActive(active: Boolean) {
        _telemetry.update { it.copy(isOverlayActive = active) }
        if (!active) {
            overlayBoundsOnScreen = null
        }
    }

    companion object {
        private const val PREFS_NAME = "k3_autobot_prefs"
        private const val KEY_TARGET = "fixed_target"
        private const val KEY_QUICK_BASE = "quick_fill_base"
        private const val KEY_QUICK_MULT = "quick_fill_multiplier"
        private const val KEY_LEVEL_PREFIX = "level_amount_"

        @Volatile
        private var instance: BotConfigRepository? = null

        fun getInstance(context: Context): BotConfigRepository {
            return instance ?: synchronized(this) {
                instance ?: BotConfigRepository(context).also { instance = it }
            }
        }
    }
}

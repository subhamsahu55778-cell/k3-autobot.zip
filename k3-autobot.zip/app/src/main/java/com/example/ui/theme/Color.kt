package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ObsidianBg = Color(0xFF0B0F17)
val SurfaceCard = Color(0xFF131A26)
val SurfaceElevated = Color(0xFF1B2434)
val BorderSubtle = Color(0xFF283548)

val EmeraldPrimary = Color(0xFF00E676)
val EmeraldDim = Color(0xFF00C853)
val EmeraldContainer = Color(0xFF0D3324)

val AmberAccent = Color(0xFFFFB300)
val AmberContainer = Color(0xFF33260B)

val SkyBlueAccent = Color(0xFF38BDF8)
val SkyContainer = Color(0xFF0E2A3A)

val CrimsonError = Color(0xFFFF5252)
val CrimsonContainer = Color(0xFF3B1519)

val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

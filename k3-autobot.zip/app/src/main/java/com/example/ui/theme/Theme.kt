package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp

private val AppDarkColorScheme = darkColorScheme(
    primary = EmeraldPrimary,
    onPrimary = ObsidianBg,
    primaryContainer = EmeraldContainer,
    onPrimaryContainer = EmeraldPrimary,
    secondary = AmberAccent,
    onSecondary = ObsidianBg,
    secondaryContainer = AmberContainer,
    onSecondaryContainer = AmberAccent,
    tertiary = SkyBlueAccent,
    onTertiary = ObsidianBg,
    tertiaryContainer = SkyContainer,
    onTertiaryContainer = SkyBlueAccent,
    background = ObsidianBg,
    onBackground = TextPrimary,
    surface = SurfaceCard,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceElevated,
    onSurfaceVariant = TextSecondary,
    outline = BorderSubtle,
    error = CrimsonError,
    onError = TextPrimary,
    errorContainer = CrimsonContainer,
    onErrorContainer = CrimsonError,
)

private val AppShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(18.dp),
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = AppDarkColorScheme,
        typography = Typography,
        shapes = AppShapes,
        content = content,
    )
}

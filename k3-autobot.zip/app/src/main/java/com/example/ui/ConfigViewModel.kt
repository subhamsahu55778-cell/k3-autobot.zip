package com.example.ui

import android.app.Application
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import com.example.data.BotConfigRepository
import com.example.model.BetTarget
import com.example.model.BotConfig
import com.example.model.BotTelemetry
import com.example.service.K3AccessibilityService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class ConfigUiState(
    val accessibilityGranted: Boolean = false,
    val overlayGranted: Boolean = false,
    val target: BetTarget = BetTarget.BIG,
    val quickFillBaseInput: String = "10",
    val quickFillMultiplier: Int = 2,
    val levelInputs: List<String> = BotConfig.defaultLevelAmounts().map { it.toString() },
    val hasUnsavedChanges: Boolean = false,
    val bannerFeedback: String? = null,
)

class ConfigViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = BotConfigRepository.getInstance(application)
    val telemetry: StateFlow<BotTelemetry> = repository.telemetry

    private val _uiState = MutableStateFlow(createInitialState())
    val uiState: StateFlow<ConfigUiState> = _uiState.asStateFlow()

    private fun createInitialState(): ConfigUiState {
        val cfg = repository.config.value
        val ctx = getApplication<Application>()
        return ConfigUiState(
            accessibilityGranted = K3AccessibilityService.isServiceEnabled(ctx),
            overlayGranted = Settings.canDrawOverlays(ctx),
            target = cfg.target,
            quickFillBaseInput = cfg.quickFillBase.toString(),
            quickFillMultiplier = cfg.quickFillMultiplier,
            levelInputs = cfg.levelAmounts.map { it.toString() },
        )
    }

    fun refreshPermissions() {
        val ctx = getApplication<Application>()
        val a11y = K3AccessibilityService.isServiceEnabled(ctx)
        val overlay = Settings.canDrawOverlays(ctx)
        repository.setAccessibilityConnected(a11y)
        _uiState.update {
            it.copy(
                accessibilityGranted = a11y,
                overlayGranted = overlay,
            )
        }
    }

    fun selectTarget(target: BetTarget) {
        _uiState.update {
            it.copy(
                target = target,
                hasUnsavedChanges = true,
                bannerFeedback = null,
            )
        }
    }

    fun updateQuickFillBase(raw: String) {
        val digitsOnly = raw.filter { it.isDigit() }.take(6)
        _uiState.update {
            it.copy(
                quickFillBaseInput = digitsOnly,
                bannerFeedback = null,
            )
        }
    }

    fun selectQuickFillMultiplier(multiplier: Int) {
        _uiState.update {
            it.copy(
                quickFillMultiplier = multiplier.coerceIn(2, 3),
                bannerFeedback = null,
            )
        }
    }

    fun applyQuickFill() {
        val current = _uiState.value
        val base = current.quickFillBaseInput.toIntOrNull()?.coerceAtLeast(1) ?: 10
        val generated = BotConfig.defaultLevelAmounts(base, current.quickFillMultiplier)
        _uiState.update {
            it.copy(
                quickFillBaseInput = base.toString(),
                levelInputs = generated.map { amt -> amt.toString() },
                hasUnsavedChanges = true,
                bannerFeedback = "Populated 15 levels (${base} × ${current.quickFillMultiplier}x). Tap Save Config to persist.",
            )
        }
    }

    fun updateLevelInput(index: Int, raw: String) {
        if (index !in 0 until BotConfig.LEVEL_COUNT) return
        val digitsOnly = raw.filter { it.isDigit() }.take(7)
        _uiState.update { state ->
            val updated = state.levelInputs.toMutableList()
            updated[index] = digitsOnly
            state.copy(
                levelInputs = updated,
                hasUnsavedChanges = true,
                bannerFeedback = null,
            )
        }
    }

    fun saveConfiguration(): Boolean {
        val state = _uiState.value
        val parsedLevels = state.levelInputs.mapIndexed { idx, raw ->
            val parsed = raw.toIntOrNull()
            if (parsed == null || parsed <= 0) {
                _uiState.update {
                    it.copy(bannerFeedback = "Level ${idx + 1} must be a positive integer amount.")
                }
                return false
            }
            parsed
        }
        val base = state.quickFillBaseInput.toIntOrNull()?.coerceAtLeast(1) ?: 10
        val newConfig = BotConfig(
            target = state.target,
            levelAmounts = parsedLevels,
            quickFillBase = base,
            quickFillMultiplier = state.quickFillMultiplier,
        )
        repository.saveConfig(newConfig)
        _uiState.update {
            it.copy(
                levelInputs = parsedLevels.map { amt -> amt.toString() },
                quickFillBaseInput = base.toString(),
                hasUnsavedChanges = false,
                bannerFeedback = "Configuration saved (${newConfig.target.label} • 15 levels).",
            )
        }
        return true
    }

    fun clearFeedback() {
        _uiState.update { it.copy(bannerFeedback = null) }
    }
}

package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Launch
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.BetTarget
import com.example.model.BotConfig
import com.example.model.BotTelemetry
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.AmberContainer
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.CrimsonContainer
import com.example.ui.theme.CrimsonError
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.SkyBlueAccent
import com.example.ui.theme.SkyContainer
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceElevated

@Composable
fun ConfigScreen(
    uiState: ConfigUiState,
    telemetry: BotTelemetry,
    onOpenAccessibilitySettings: () -> Unit,
    onOpenOverlaySettings: () -> Unit,
    onSelectTarget: (BetTarget) -> Unit,
    onQuickFillBaseChanged: (String) -> Unit,
    onSelectQuickFillMultiplier: (Int) -> Unit,
    onApplyQuickFill: () -> Unit,
    onLevelInputChanged: (Int, String) -> Unit,
    onSaveConfiguration: () -> Unit,
    onLaunchOverlay: () -> Unit,
) {
    Scaffold(
        containerColor = ObsidianBg,
        contentWindowInsets = WindowInsets.safeDrawing,
        bottomBar = {
            BottomActionBar(
                hasUnsavedChanges = uiState.hasUnsavedChanges,
                canLaunch = uiState.overlayGranted && uiState.accessibilityGranted,
                onSave = onSaveConfiguration,
                onLaunchOverlay = onLaunchOverlay,
            )
        },
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter,
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 640.dp),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                item {
                    HeroHeaderCard(telemetry = telemetry)
                }

                item {
                    AnimatedVisibility(visible = uiState.bannerFeedback != null) {
                        FeedbackBanner(message = uiState.bannerFeedback.orEmpty())
                    }
                }

                item {
                    SectionLabel(
                        icon = Icons.Filled.Shield,
                        title = "System Permissions",
                    )
                }

                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        PermissionStatusCard(
                            title = stringResource(R.string.perm_accessibility_title),
                            description = stringResource(R.string.perm_accessibility_desc),
                            granted = uiState.accessibilityGranted,
                            testTag = "accessibility_permission_button",
                            onClick = onOpenAccessibilitySettings,
                        )
                        PermissionStatusCard(
                            title = stringResource(R.string.perm_overlay_title),
                            description = stringResource(R.string.perm_overlay_desc),
                            granted = uiState.overlayGranted,
                            testTag = "overlay_permission_button",
                            onClick = onOpenOverlaySettings,
                        )
                    }
                }

                item {
                    SectionLabel(
                        icon = Icons.Filled.AutoAwesome,
                        title = stringResource(R.string.target_section_title),
                    )
                }

                item {
                    TargetSelectorCard(
                        selectedTarget = uiState.target,
                        onSelectTarget = onSelectTarget,
                    )
                }

                item {
                    SectionLabel(
                        icon = Icons.Filled.Layers,
                        title = stringResource(R.string.levels_section_title),
                    )
                }

                item {
                    QuickFillHelperCard(
                        baseInput = uiState.quickFillBaseInput,
                        multiplier = uiState.quickFillMultiplier,
                        onBaseChanged = onQuickFillBaseChanged,
                        onSelectMultiplier = onSelectQuickFillMultiplier,
                        onApply = onApplyQuickFill,
                    )
                }

                item {
                    LevelsGridCard(
                        levelInputs = uiState.levelInputs,
                        onLevelChanged = onLevelInputChanged,
                    )
                }

                item {
                    Spacer(modifier = Modifier.height(8.dp))
                }
            }
        }
    }
}

@Composable
private fun HeroHeaderCard(telemetry: BotTelemetry) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
        border = BorderStroke(1.dp, BorderSubtle),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(148.dp),
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_hero_banner),
                contentDescription = stringResource(R.string.hero_banner_desc),
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                ObsidianBg.copy(alpha = 0.25f),
                                ObsidianBg.copy(alpha = 0.88f),
                            )
                        )
                    ),
            )
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.SpaceBetween,
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Surface(
                        color = ObsidianBg.copy(alpha = 0.78f),
                        shape = RoundedCornerShape(999.dp),
                        border = BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.35f)),
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (telemetry.status.isRunning) EmeraldPrimary else AmberAccent
                                    )
                            )
                            Text(
                                text = telemetry.status.displayLabel,
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White,
                            )
                        }
                    }

                    Text(
                        text = "K3_1M ENGINE",
                        style = MaterialTheme.typography.labelSmall,
                        color = EmeraldPrimary,
                    )
                }

                Column {
                    Text(
                        text = "K3 AutoBot Controller",
                        style = MaterialTheme.typography.headlineSmall,
                        color = Color.White,
                    )
                    Text(
                        text = "15-Level Progression • ML Kit OCR + Accessibility Hybrid",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

@Composable
private fun FeedbackBanner(message: String) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = EmeraldContainer,
        border = BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.45f)),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Text(
            text = message,
            style = MaterialTheme.typography.bodySmall,
            color = EmeraldPrimary,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
        )
    }
}

@Composable
private fun SectionLabel(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.padding(top = 4.dp),
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = EmeraldPrimary,
            modifier = Modifier.size(18.dp),
        )
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onBackground,
        )
    }
}

@Composable
private fun PermissionStatusCard(
    title: String,
    description: String,
    granted: Boolean,
    testTag: String,
    onClick: () -> Unit,
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
        border = BorderStroke(
            1.dp,
            if (granted) EmeraldPrimary.copy(alpha = 0.4f) else CrimsonError.copy(alpha = 0.45f),
        ),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Icon(
                imageVector = if (granted) Icons.Filled.CheckCircle else Icons.Filled.Warning,
                contentDescription = null,
                tint = if (granted) EmeraldPrimary else CrimsonError,
                modifier = Modifier.size(24.dp),
            )

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = if (granted) EmeraldContainer else CrimsonContainer,
                    ) {
                        Text(
                            text = stringResource(if (granted) R.string.status_granted else R.string.status_missing),
                            style = MaterialTheme.typography.labelSmall,
                            color = if (granted) EmeraldPrimary else CrimsonError,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        )
                    }
                }
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            FilledTonalButton(
                onClick = onClick,
                modifier = Modifier.testTag(testTag),
                colors = ButtonDefaults.filledTonalButtonColors(
                    containerColor = if (granted) SurfaceElevated else CrimsonContainer,
                    contentColor = if (granted) MaterialTheme.colorScheme.onSurface else CrimsonError,
                ),
            ) {
                Text(
                    text = if (granted) "Settings" else stringResource(R.string.open_settings),
                    style = MaterialTheme.typography.labelMedium,
                )
            }
        }
    }
}

@Composable
private fun TargetSelectorCard(
    selectedTarget: BetTarget,
    onSelectTarget: (BetTarget) -> Unit,
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
        border = BorderStroke(1.dp, BorderSubtle),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text(
                text = "Lock automated bets exclusively to Big 2X or Small 2X.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                BetTarget.entries.forEachIndexed { index, target ->
                    val isSelected = selectedTarget == target
                    val accent = if (target == BetTarget.BIG) AmberAccent else SkyBlueAccent
                    val container = if (target == BetTarget.BIG) AmberContainer else SkyContainer

                    SegmentedButton(
                        selected = isSelected,
                        onClick = { onSelectTarget(target) },
                        shape = SegmentedButtonDefaults.itemShape(
                            index = index,
                            count = BetTarget.entries.size,
                        ),
                        colors = SegmentedButtonDefaults.colors(
                            activeContainerColor = container,
                            activeContentColor = accent,
                            inactiveContainerColor = SurfaceElevated,
                            inactiveContentColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        ),
                        modifier = Modifier.testTag("target_${target.name.lowercase()}_button"),
                    ) {
                        Text(
                            text = "${target.label.uppercase()} (${target.buttonLabel})",
                            style = MaterialTheme.typography.labelLarge,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun QuickFillHelperCard(
    baseInput: String,
    multiplier: Int,
    onBaseChanged: (String) -> Unit,
    onSelectMultiplier: (Int) -> Unit,
    onApply: () -> Unit,
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
        border = BorderStroke(1.dp, BorderSubtle),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text(
                text = stringResource(R.string.quick_fill_title),
                style = MaterialTheme.typography.titleSmall,
                color = AmberAccent,
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                OutlinedTextField(
                    value = baseInput,
                    onValueChange = onBaseChanged,
                    label = { Text(stringResource(R.string.base_amount_label)) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    textStyle = MaterialTheme.typography.labelLarge.copy(
                        fontFamily = JetBrainsMonoFontFamily,
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AmberAccent,
                        unfocusedBorderColor = BorderSubtle,
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("quick_fill_base_input"),
                )

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(2, 3).forEach { mult ->
                        val active = multiplier == mult
                        OutlinedButton(
                            onClick = { onSelectMultiplier(mult) },
                            border = BorderStroke(
                                1.dp,
                                if (active) AmberAccent else BorderSubtle,
                            ),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = if (active) AmberContainer else SurfaceElevated,
                                contentColor = if (active) AmberAccent else MaterialTheme.colorScheme.onSurfaceVariant,
                            ),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 12.dp),
                            modifier = Modifier.testTag("quick_fill_mult_${mult}x"),
                        ) {
                            Text("${mult}x", style = MaterialTheme.typography.labelLarge)
                        }
                    }
                }

                Button(
                    onClick = onApply,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = AmberAccent,
                        contentColor = ObsidianBg,
                    ),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 14.dp),
                    modifier = Modifier.testTag("quick_fill_apply_button"),
                ) {
                    Text(
                        text = stringResource(R.string.apply_quick_fill),
                        style = MaterialTheme.typography.labelLarge,
                    )
                }
            }
        }
    }
}

@Composable
private fun LevelsGridCard(
    levelInputs: List<String>,
    onLevelChanged: (Int, String) -> Unit,
) {
    val totalExposure = levelInputs.sumOf { it.toLongOrNull() ?: 0L }

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
        border = BorderStroke(1.dp, BorderSubtle),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = "Editable Level 1 – Level 15 (₹)",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text(
                    text = "15-Lvl Sum: ₹$totalExposure",
                    style = MaterialTheme.typography.labelMedium,
                    color = EmeraldPrimary,
                )
            }

            // 5 rows of 3 inputs = 15 numbered fields
            for (rowIndex in 0 until 5) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    for (colIndex in 0 until 3) {
                        val levelIndex = rowIndex * 3 + colIndex
                        if (levelIndex < BotConfig.LEVEL_COUNT) {
                            OutlinedTextField(
                                value = levelInputs[levelIndex],
                                onValueChange = { onLevelChanged(levelIndex, it) },
                                label = {
                                    Text(
                                        text = "L${levelIndex + 1}",
                                        style = MaterialTheme.typography.labelSmall,
                                    )
                                },
                                prefix = {
                                    Text(
                                        text = "₹",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = AmberAccent,
                                    )
                                },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                textStyle = MaterialTheme.typography.labelMedium.copy(
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontWeight = FontWeight.Bold,
                                ),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = EmeraldPrimary,
                                    unfocusedBorderColor = BorderSubtle,
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("level_input_${levelIndex + 1}"),
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BottomActionBar(
    hasUnsavedChanges: Boolean,
    canLaunch: Boolean,
    onSave: () -> Unit,
    onLaunchOverlay: () -> Unit,
) {
    Surface(
        color = SurfaceCard,
        tonalElevation = 8.dp,
        border = BorderStroke(1.dp, BorderSubtle),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            OutlinedButton(
                onClick = onSave,
                border = BorderStroke(
                    1.5.dp,
                    if (hasUnsavedChanges) AmberAccent else BorderSubtle,
                ),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = if (hasUnsavedChanges) AmberAccent else MaterialTheme.colorScheme.onSurface,
                ),
                modifier = Modifier
                    .weight(1f)
                    .height(50.dp)
                    .testTag("save_config_button"),
            ) {
                Icon(
                    imageVector = Icons.Filled.Save,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp),
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = stringResource(R.string.save_config),
                    style = MaterialTheme.typography.labelLarge,
                    maxLines = 1,
                )
            }

            Button(
                onClick = onLaunchOverlay,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (canLaunch) EmeraldPrimary else SurfaceElevated,
                    contentColor = if (canLaunch) ObsidianBg else MaterialTheme.colorScheme.onSurfaceVariant,
                ),
                modifier = Modifier
                    .weight(1.25f)
                    .height(50.dp)
                    .testTag("launch_overlay_button"),
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Launch,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp),
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = stringResource(R.string.launch_overlay),
                    style = MaterialTheme.typography.labelLarge,
                    maxLines = 1,
                )
            }
        }
    }
}

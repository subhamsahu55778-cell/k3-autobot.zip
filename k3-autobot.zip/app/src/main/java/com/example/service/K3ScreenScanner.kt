package com.example.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.graphics.Bitmap
import android.graphics.Rect
import android.os.Build
import android.view.Display
import android.view.accessibility.AccessibilityNodeInfo
import com.example.ocr.OcrHelper
import com.example.ocr.ScreenElement
import kotlin.coroutines.resume
import kotlinx.coroutines.suspendCancellableCoroutine

data class CapturedScreen(
    val nodeElements: List<ScreenElement>,
    val ocrElements: List<ScreenElement>,
    val rawNodes: List<AccessibilityNodeInfo>,
) {
    val allElements: List<ScreenElement>
        get() = if (ocrElements.isEmpty()) nodeElements else nodeElements + ocrElements
}

class K3ScreenScanner(
    private val service: AccessibilityService,
    private val ocrHelper: OcrHelper,
) {

    fun collectAccessibilityNodes(ownPackageName: String): Pair<List<ScreenElement>, List<AccessibilityNodeInfo>> {
        val elements = mutableListOf<ScreenElement>()
        val rawNodes = mutableListOf<AccessibilityNodeInfo>()

        val roots = mutableListOf<AccessibilityNodeInfo>()
        service.windows?.forEach { window ->
            val root = window.root
            if (root != null && root.packageName?.toString() != ownPackageName) {
                roots += root
            }
        }
        if (roots.isEmpty()) {
            service.rootInActiveWindow?.let { root ->
                if (root.packageName?.toString() != ownPackageName) {
                    roots += root
                }
            }
        }

        for (root in roots) {
            traverseNode(root, elements, rawNodes)
        }
        return elements to rawNodes
    }

    private fun traverseNode(
        node: AccessibilityNodeInfo,
        elements: MutableList<ScreenElement>,
        rawNodes: MutableList<AccessibilityNodeInfo>,
    ) {
        if (!node.isVisibleToUser) return

        val rect = Rect()
        node.getBoundsInScreen(rect)
        if (rect.width() > 0 && rect.height() > 0) {
            val text = node.text?.toString()?.trim().orEmpty()
            val desc = node.contentDescription?.toString()?.trim().orEmpty()
            val label = when {
                text.isNotEmpty() -> text
                desc.isNotEmpty() -> desc
                else -> ""
            }
            if (label.isNotEmpty() || node.isEditable || node.isCheckable || node.isClickable) {
                elements += ScreenElement(
                    text = label,
                    bounds = rect,
                    isClickable = node.isClickable,
                    isEditable = node.isEditable,
                    isCheckable = node.isCheckable,
                    isChecked = node.isChecked,
                    fromOcr = false,
                )
                rawNodes += node
            }
        }

        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            traverseNode(child, elements, rawNodes)
        }
    }

    suspend fun scanScreen(
        ownPackageName: String,
        overlayBounds: Rect?,
        forceOcr: Boolean = false,
    ): CapturedScreen {
        val (nodeElements, rawNodes) = collectAccessibilityNodes(ownPackageName)
        val hasPeriodInNodes = OcrHelper.extractActivePeriodId(nodeElements) != null
        val hasTimerInNodes = OcrHelper.extractRemainingSeconds(nodeElements) != null

        val ocrElements = if (forceOcr || !hasPeriodInNodes || !hasTimerInNodes) {
            runOcrExcludingOverlay(overlayBounds)
        } else {
            emptyList()
        }

        return CapturedScreen(
            nodeElements = nodeElements,
            ocrElements = ocrElements,
            rawNodes = rawNodes,
        )
    }

    suspend fun runOcrExcludingOverlay(overlayBounds: Rect?): List<ScreenElement> {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return emptyList()
        val bitmap = captureScreenBitmapR() ?: return emptyList()
        return try {
            val snapshot = ocrHelper.recognizeBitmap(bitmap)
            (snapshot.lines + snapshot.elements).filter { element ->
                overlayBounds == null || !isMostlyInside(element.bounds, overlayBounds)
            }
        } catch (_: Exception) {
            emptyList()
        } finally {
            bitmap.recycle()
        }
    }

    private fun isMostlyInside(box: Rect, overlay: Rect): Boolean {
        return overlay.contains(box.centerX(), box.centerY())
    }

    private suspend fun captureScreenBitmapR(): Bitmap? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return null
        return suspendCancellableCoroutine { cont ->
            service.takeScreenshot(
                Display.DEFAULT_DISPLAY,
                service.mainExecutor,
                object : TakeScreenshotCallback {
                    override fun onSuccess(screenshot: ScreenshotResult) {
                        val hwBuffer = screenshot.hardwareBuffer
                        val colorSpace = screenshot.colorSpace
                        var swBitmap: Bitmap? = null
                        try {
                            val hwBitmap = Bitmap.wrapHardwareBuffer(hwBuffer, colorSpace)
                            swBitmap = hwBitmap?.copy(Bitmap.Config.ARGB_8888, false)
                            hwBitmap?.recycle()
                        } finally {
                            hwBuffer.close()
                        }
                        if (cont.isActive) cont.resume(swBitmap)
                    }

                    override fun onFailure(errorCode: Int) {
                        if (cont.isActive) cont.resume(null)
                    }
                },
            )
        }
    }
}

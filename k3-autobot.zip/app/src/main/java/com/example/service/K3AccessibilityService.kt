package com.example.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ComponentName
import android.content.Context
import android.graphics.Path
import android.graphics.Rect
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import android.text.TextUtils
import android.util.DisplayMetrics
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.example.data.BotConfigRepository
import com.example.model.BetTarget
import com.example.model.BotStatus
import com.example.ocr.OcrHelper
import com.example.ocr.ScreenElement
import kotlin.coroutines.resume
import kotlin.math.abs
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine

class K3AccessibilityService : AccessibilityService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private lateinit var repository: BotConfigRepository
    private lateinit var ocrHelper: OcrHelper
    private lateinit var scanner: K3ScreenScanner

    private var automationJob: Job? = null
    private var lastBetPeriod: String = ""
    private var currentLevel: Int = 1

    override fun onServiceConnected() {
        super.onServiceConnected()
        repository = BotConfigRepository.getInstance(this)
        ocrHelper = OcrHelper()
        scanner = K3ScreenScanner(this, ocrHelper)
        repository.setAccessibilityConnected(true)

        serviceScope.launch {
            repository.automationRequested.collect { requested ->
                if (requested) {
                    startAutomationLoop()
                } else {
                    stopAutomationLoop()
                }
            }
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Driven deterministically by the 500ms state-machine loop when active.
    }

    override fun onInterrupt() {
        repository.requestStopAutomation(BotStatus.IDLE, "Accessibility interrupted")
    }

    override fun onDestroy() {
        repository.setAccessibilityConnected(false)
        repository.requestStopAutomation(BotStatus.IDLE, "Accessibility disconnected")
        stopAutomationLoop()
        ocrHelper.close()
        serviceScope.cancel()
        super.onDestroy()
    }

    private fun startAutomationLoop() {
        if (automationJob?.isActive == true) return
        lastBetPeriod = ""
        currentLevel = 1

        automationJob = serviceScope.launch {
            var missingScreenRetries = 0
            while (isActive && repository.automationRequested.value) {
                try {
                    val config = repository.config.value
                    val activeAmount = config.amountForLevel(currentLevel)

                    // Dismiss any lingering result overlay first
                    val preScan = scanner.scanScreen(
                        ownPackageName = packageName,
                        overlayBounds = repository.overlayBoundsOnScreen,
                    )
                    if (isResultPopupVisible(preScan.allElements)) {
                        dismissResultPopupIfPresent(preScan)
                        delay(500)
                        continue
                    }

                    // Phase A: Round & Timer Monitoring
                    val currentPeriod = OcrHelper.extractActivePeriodId(preScan.allElements)
                    val remainingSeconds = OcrHelper.extractRemainingSeconds(preScan.allElements)

                    repository.updateTelemetry {
                        it.copy(
                            currentPeriod = currentPeriod ?: it.currentPeriod,
                            remainingSeconds = remainingSeconds,
                            currentLevel = currentLevel,
                            activeAmount = activeAmount,
                            target = config.target,
                        )
                    }

                    if (currentPeriod == null || remainingSeconds == null) {
                        missingScreenRetries++
                        if (missingScreenRetries > 2) {
                            triggerErrorStop("Period or timer not found")
                            break
                        }
                        delay(500)
                        continue
                    }
                    missingScreenRetries = 0

                    if (currentPeriod == lastBetPeriod) {
                        repository.updateTelemetry {
                            it.copy(
                                status = BotStatus.VERIFYING_RESULT,
                                statusMessage = "Waiting for round end",
                            )
                        }
                        delay(500)
                        continue
                    }

                    // Timer Buffer Rule: never click during final 10 seconds (00:00..00:09)
                    if (remainingSeconds < 10) {
                        repository.updateTelemetry {
                            it.copy(
                                status = BotStatus.WAITING_FOR_NEXT_ROUND,
                                statusMessage = "Buffer <10s (${remainingSeconds}s)",
                            )
                        }
                        delay(500)
                        continue
                    }

                    // Phase B: Smart Vertical Scroll & Viewport Anchoring
                    repository.updateTelemetry {
                        it.copy(
                            status = BotStatus.PLACING_BET,
                            statusMessage = "Locating ${config.target.buttonLabel}",
                        )
                    }

                    val targetButton = locateAndAnchorBetButton(config.target)
                    if (targetButton == null) {
                        triggerErrorStop("${config.target.buttonLabel} not found")
                        break
                    }

                    if (!dispatchTap(targetButton.bounds.centerX().toFloat(), targetButton.bounds.centerY().toFloat())) {
                        triggerErrorStop("Tap failed on ${config.target.buttonLabel}")
                        break
                    }

                    // Phase C: Amount Popup Modal Execution
                    val modalPlaced = executeAmountModal(activeAmount)
                    if (!modalPlaced) {
                        // executeAmountModal already triggers exact error message on failure
                        break
                    }

                    lastBetPeriod = currentPeriod
                    repository.updateTelemetry {
                        it.copy(
                            status = BotStatus.VERIFYING_RESULT,
                            lastBetPeriod = lastBetPeriod,
                            statusMessage = "Bet ₹$activeAmount placed",
                        )
                    }

                    // Phase D: Result Detection, Popup Dismissal & 15-Level Progression
                    val roundSettled = handlePhaseDResultAndProgression(
                        betPeriod = lastBetPeriod,
                        target = config.target,
                    )
                    if (!roundSettled) {
                        break
                    }
                } catch (ce: CancellationException) {
                    throw ce
                } catch (e: Exception) {
                    triggerErrorStop(e.message ?: "Unexpected engine error")
                    break
                }
                delay(500)
            }
        }
    }

    private fun stopAutomationLoop() {
        automationJob?.cancel()
        automationJob = null
    }

    private suspend fun locateAndAnchorBetButton(target: BetTarget): ScreenElement? {
        val (screenW, screenH) = getScreenSize()
        val middleMinY = (screenH * 0.25f).toInt()
        val middleMaxY = (screenH * 0.75f).toInt()
        val safeTopY = (screenH * 0.12f).toInt()
        val safeBottomY = (screenH * 0.88f).toInt()

        for (attempt in 0..2) {
            val scan = scanner.scanScreen(
                ownPackageName = packageName,
                overlayBounds = repository.overlayBoundsOnScreen,
                forceOcr = attempt > 0,
            )
            val candidate = findBetButtonElement(scan.allElements, target)
            val overlayRect = repository.overlayBoundsOnScreen

            if (candidate != null) {
                val cy = candidate.bounds.centerY()
                val cx = candidate.bounds.centerX()
                val isClipped = candidate.bounds.top < safeTopY || candidate.bounds.bottom > safeBottomY
                val isOccluded = overlayRect != null && overlayRect.contains(cx, cy)
                val isCentered = cy in middleMinY..middleMaxY

                if (!isClipped && !isOccluded && (isCentered || attempt == 2)) {
                    return candidate
                }

                // Scroll to bring candidate into unobstructed middle 50%
                val desiredY = screenH * 0.50f
                val deltaY = desiredY - cy
                val startY = screenH * 0.55f
                val endY = (startY + deltaY.coerceIn(-screenH * 0.35f, screenH * 0.35f))
                dispatchSwipe(screenW * 0.5f, startY, screenW * 0.5f, endY, 350L)
                delay(400)
                continue
            }

            if (attempt < 2) {
                // If Game history is visible, scroll up (swipe down); otherwise scroll down (swipe up)
                val historyVisible = scan.allElements.any {
                    it.text.contains("game history", ignoreCase = true) ||
                        it.text.contains("my history", ignoreCase = true)
                }
                if (historyVisible) {
                    dispatchSwipe(screenW * 0.5f, screenH * 0.35f, screenW * 0.5f, screenH * 0.75f, 350L)
                } else {
                    dispatchSwipe(screenW * 0.5f, screenH * 0.72f, screenW * 0.5f, screenH * 0.32f, 350L)
                }
                delay(400)
            }
        }
        return null
    }

    private fun findBetButtonElement(elements: List<ScreenElement>, target: BetTarget): ScreenElement? {
        val exactPattern = if (target == BetTarget.BIG) {
            Regex("""\bbig\s*2\s*x\b""", RegexOption.IGNORE_CASE)
        } else {
            Regex("""\bsmall\s*2\s*x\b""", RegexOption.IGNORE_CASE)
        }
        val exactMatch = elements.firstOrNull { exactPattern.containsMatchIn(it.text) }
        if (exactMatch != null) return exactMatch

        // Fallback: match standalone "Big" / "Small" button in the Total section (not in Game history)
        val historyY = OcrHelper.findHistoryHeaderBottom(elements)
        val wordPattern = if (target == BetTarget.BIG) {
            Regex("""^big$""", RegexOption.IGNORE_CASE)
        } else {
            Regex("""^small$""", RegexOption.IGNORE_CASE)
        }
        return elements.firstOrNull { el ->
            wordPattern.matches(el.text.trim()) &&
                (historyY == null || el.bounds.bottom < historyY) &&
                el.bounds.height() >= 30
        }
    }

    private suspend fun executeAmountModal(targetAmount: Int): Boolean {
        var modalScan: CapturedScreen? = null
        for (attempt in 0..2) {
            delay(350)
            val scan = scanner.scanScreen(
                ownPackageName = packageName,
                overlayBounds = repository.overlayBoundsOnScreen,
                forceOcr = attempt > 0,
            )
            if (isAmountModalVisible(scan.allElements)) {
                modalScan = scan
                break
            }
        }
        val initialModal = modalScan ?: run {
            triggerErrorStop("Amount popup modal missing")
            return false
        }

        // Step 1: Select Base Unit "1" in Balance row
        val baseOneEl = findBaseUnitElement(initialModal.allElements, 1)
        if (baseOneEl != null) {
            dispatchTap(baseOneEl.bounds.centerX().toFloat(), baseOneEl.bounds.centerY().toFloat())
            delay(200)
        }

        // Step 2: Clear & inject exact custom level amount into Quantity input
        val refreshedAfterBase = scanner.scanScreen(
            ownPackageName = packageName,
            overlayBounds = repository.overlayBoundsOnScreen,
            forceOcr = false,
        )
        val injectedViaNode = tryInjectQuantityViaNode(refreshedAfterBase, targetAmount)
        delay(250)

        var checkScan = scanner.scanScreen(
            ownPackageName = packageName,
            overlayBounds = repository.overlayBoundsOnScreen,
            forceOcr = true,
        )
        var observedTotal = OcrHelper.extractTotalAmountRupees(checkScan.allElements)

        if (!injectedViaNode || observedTotal == null || abs(observedTotal - targetAmount) > 0.01) {
            // Fallback: compute exact combination of Base Units, Multiplier chips, and '+' taps
            val planApplied = applyFallbackAmountPlan(checkScan, targetAmount)
            if (!planApplied) {
                triggerErrorStop("Quantity input / multiplier controls unavailable")
                return false
            }
            delay(250)
            checkScan = scanner.scanScreen(
                ownPackageName = packageName,
                overlayBounds = repository.overlayBoundsOnScreen,
                forceOcr = true,
            )
            observedTotal = OcrHelper.extractTotalAmountRupees(checkScan.allElements)
        }

        // Step 3: Agreement checkbox verification
        ensureAgreementChecked(checkScan)

        // Step 4: Pre-submit amount verification & confirmation
        val finalScan = scanner.scanScreen(
            ownPackageName = packageName,
            overlayBounds = repository.overlayBoundsOnScreen,
            forceOcr = true,
        )
        val verifiedTotal = OcrHelper.extractTotalAmountRupees(finalScan.allElements) ?: observedTotal
        if (verifiedTotal == null || abs(verifiedTotal - targetAmount.toDouble()) > 0.01) {
            triggerErrorStop("Amount mismatch: expected ₹$targetAmount, got ₹${verifiedTotal ?: "?"}")
            return false
        }

        val submitBtn = findTotalAmountButton(finalScan.allElements)
        if (submitBtn == null) {
            triggerErrorStop("Total amount submit button missing")
            return false
        }

        if (!dispatchTap(submitBtn.bounds.centerX().toFloat(), submitBtn.bounds.centerY().toFloat())) {
            triggerErrorStop("Failed to tap Total amount button")
            return false
        }
        delay(450)
        return true
    }

    private fun isAmountModalVisible(elements: List<ScreenElement>): Boolean {
        val hasBalance = elements.any { it.text.contains("balance", ignoreCase = true) }
        val hasQuantity = elements.any { it.text.contains("quantity", ignoreCase = true) }
        val hasTotal = elements.any { it.text.contains("total amount", ignoreCase = true) }
        return hasTotal && (hasBalance || hasQuantity)
    }

    private fun findBaseUnitElement(elements: List<ScreenElement>, unit: Int): ScreenElement? {
        val label = if (unit >= 1000) "1K" else unit.toString()
        val balanceAnchor = elements.firstOrNull { it.text.contains("balance", ignoreCase = true) }
        val pool = if (balanceAnchor != null) {
            elements.filter {
                abs(it.bounds.centerY() - balanceAnchor.bounds.centerY()) <= 90 &&
                    it.bounds.left >= balanceAnchor.bounds.left
            }
        } else {
            elements
        }
        return pool.firstOrNull { it.text.trim().equals(label, ignoreCase = true) }
    }

    private fun tryInjectQuantityViaNode(scan: CapturedScreen, targetAmount: Int): Boolean {
        val quantityAnchor = scan.allElements.firstOrNull { it.text.contains("quantity", ignoreCase = true) }
        val editableNodes = scan.rawNodes.filter { node ->
            if (!node.isEditable) return@filter false
            if (quantityAnchor == null) return@filter true
            val rect = Rect()
            node.getBoundsInScreen(rect)
            abs(rect.centerY() - quantityAnchor.bounds.centerY()) <= 110
        }
        val inputNode = editableNodes.firstOrNull() ?: return false

        val rect = Rect()
        inputNode.getBoundsInScreen(rect)
        inputNode.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        inputNode.performAction(AccessibilityNodeInfo.ACTION_CLICK)

        val clearArgs = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, "")
        }
        inputNode.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, clearArgs)

        val setArgs = Bundle().apply {
            putCharSequence(
                AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                targetAmount.toString(),
            )
        }
        return inputNode.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, setArgs)
    }

    private suspend fun applyFallbackAmountPlan(scan: CapturedScreen, targetAmount: Int): Boolean {
        val plan = OcrHelper.computeAmountClickPlan(targetAmount)
        val baseEl = findBaseUnitElement(scan.allElements, plan.baseUnit) ?: return false
        dispatchTap(baseEl.bounds.centerX().toFloat(), baseEl.bounds.centerY().toFloat())
        delay(180)

        val chipLabel = "X${plan.multiplierChip}"
        val chipEl = scan.allElements.firstOrNull {
            it.text.trim().equals(chipLabel, ignoreCase = true)
        }
        if (chipEl != null) {
            dispatchTap(chipEl.bounds.centerX().toFloat(), chipEl.bounds.centerY().toFloat())
            delay(180)
        } else if (plan.multiplierChip > 1) {
            return false
        }

        if (plan.plusTaps > 0) {
            val plusEl = findQuantityPlusButton(scan.allElements) ?: return false
            repeat(plan.plusTaps) {
                dispatchTap(plusEl.bounds.centerX().toFloat(), plusEl.bounds.centerY().toFloat())
                delay(120)
            }
        }
        return true
    }

    private fun findQuantityPlusButton(elements: List<ScreenElement>): ScreenElement? {
        val quantityAnchor = elements.firstOrNull { it.text.contains("quantity", ignoreCase = true) }
        val pool = if (quantityAnchor != null) {
            elements.filter { abs(it.bounds.centerY() - quantityAnchor.bounds.centerY()) <= 90 }
        } else {
            elements
        }
        return pool.lastOrNull { it.text.trim() == "+" }
    }

    private suspend fun ensureAgreementChecked(scan: CapturedScreen) {
        val agreeEl = scan.allElements.firstOrNull { it.text.contains("i agree", ignoreCase = true) } ?: return
        val checkNode = scan.rawNodes.firstOrNull { node ->
            if (!node.isCheckable) return@firstOrNull false
            val rect = Rect()
            node.getBoundsInScreen(rect)
            abs(rect.centerY() - agreeEl.bounds.centerY()) <= 80
        }
        if (checkNode != null && !checkNode.isChecked) {
            val rect = Rect()
            checkNode.getBoundsInScreen(rect)
            dispatchTap(rect.centerX().toFloat(), rect.centerY().toFloat())
            delay(180)
        }
    }

    private fun findTotalAmountButton(elements: List<ScreenElement>): ScreenElement? {
        return elements
            .filter { it.text.contains("total amount", ignoreCase = true) }
            .maxByOrNull { it.bounds.bottom }
    }

    private suspend fun handlePhaseDResultAndProgression(
        betPeriod: String,
        target: BetTarget,
    ): Boolean {
        // Wait until period changes (or max 75 seconds)
        val deadlineMs = System.currentTimeMillis() + 75_000L
        var periodChanged = false

        while (coroutineContextActive() && System.currentTimeMillis() < deadlineMs) {
            val scan = scanner.scanScreen(
                ownPackageName = packageName,
                overlayBounds = repository.overlayBoundsOnScreen,
                forceOcr = false,
            )

            // Check & update remaining timer telemetry
            val activePeriod = OcrHelper.extractActivePeriodId(scan.allElements)
            val remSec = OcrHelper.extractRemainingSeconds(scan.allElements)
            repository.updateTelemetry {
                it.copy(
                    currentPeriod = activePeriod ?: it.currentPeriod,
                    remainingSeconds = remSec,
                )
            }

            if (isResultPopupVisible(scan.allElements)) {
                dismissResultPopupIfPresent(scan)
                delay(500)
                periodChanged = true
                break
            }

            if (activePeriod != null && activePeriod != betPeriod) {
                periodChanged = true
                break
            }
            delay(500)
        }

        if (!periodChanged) {
            triggerErrorStop("Timed out waiting for round result")
            return false
        }

        // Wait briefly for any post-round popup to appear and dismiss it
        delay(600)
        val postRoundScan = scanner.scanScreen(
            ownPackageName = packageName,
            overlayBounds = repository.overlayBoundsOnScreen,
            forceOcr = true,
        )
        if (isResultPopupVisible(postRoundScan.allElements)) {
            dismissResultPopupIfPresent(postRoundScan)
            delay(500)
        }

        // Inspect Game History top row beneath Period | Sum | Results
        var historyRow = OcrHelper.parseHistoryTopRow(postRoundScan.allElements, betPeriod)
        var scrolledDownForHistory = false
        val (screenW, screenH) = getScreenSize()

        for (retry in 0..2) {
            if (historyRow != null) break
            val scan = scanner.scanScreen(
                ownPackageName = packageName,
                overlayBounds = repository.overlayBoundsOnScreen,
                forceOcr = true,
            )
            if (isResultPopupVisible(scan.allElements)) {
                dismissResultPopupIfPresent(scan)
                delay(500)
                continue
            }
            historyRow = OcrHelper.parseHistoryTopRow(scan.allElements, betPeriod)
            if (historyRow != null) break

            // Scroll down slightly to reveal Game history top row
            if (OcrHelper.findHistoryHeaderBottom(scan.allElements) == null) {
                dispatchSwipe(screenW * 0.5f, screenH * 0.72f, screenW * 0.5f, screenH * 0.38f, 320L)
                scrolledDownForHistory = true
                delay(450)
            } else {
                delay(650)
            }
        }

        if (scrolledDownForHistory) {
            dispatchSwipe(screenW * 0.5f, screenH * 0.35f, screenW * 0.5f, screenH * 0.72f, 320L)
            delay(400)
        }

        val verifiedRow = historyRow ?: run {
            triggerErrorStop("Failed to verify Period $betPeriod in Game history")
            return false
        }

        val won = verifiedRow.outcome == target
        val config = repository.config.value
        if (won) {
            currentLevel = 1
            repository.updateTelemetry {
                it.copy(
                    status = BotStatus.WAITING_FOR_NEXT_ROUND,
                    currentLevel = 1,
                    activeAmount = config.amountForLevel(1),
                    winsCount = it.winsCount + 1,
                    statusMessage = "WIN (${verifiedRow.outcome.label}) • Reset L1",
                )
            }
        } else {
            val newLosses = repository.telemetry.value.lossesCount + 1
            if (currentLevel >= 15) {
                repository.updateTelemetry { it.copy(lossesCount = newLosses) }
                triggerLevel15HardStop()
                return false
            }
            currentLevel += 1
            val nextAmount = config.amountForLevel(currentLevel)
            repository.updateTelemetry {
                it.copy(
                    status = BotStatus.WAITING_FOR_NEXT_ROUND,
                    currentLevel = currentLevel,
                    activeAmount = nextAmount,
                    lossesCount = newLosses,
                    statusMessage = "LOSS (${verifiedRow.outcome.label}) • Next L$currentLevel (₹$nextAmount)",
                )
            }
        }
        return true
    }

    private fun isResultPopupVisible(elements: List<ScreenElement>): Boolean {
        return elements.any { el ->
            val lower = el.text.lowercase()
            lower.contains("congratulations") ||
                (lower.contains("sorry") && (lower.contains("lose") || lower.contains("lost") || lower.contains("lottery"))) ||
                lower.contains("3 seconds auto close")
        }
    }

    private suspend fun dismissResultPopupIfPresent(scan: CapturedScreen) {
        val anchor = scan.allElements.firstOrNull { el ->
            val lower = el.text.lowercase()
            lower.contains("congratulations") || lower.contains("sorry") || lower.contains("auto close")
        } ?: return

        val (screenW, _) = getScreenSize()
        val closeButton = scan.allElements
            .filter { el ->
                val txt = el.text.trim().lowercase()
                val isCloseGlyph = txt == "x" || txt == "×" || txt == "✕" || txt == "close"
                val belowAnchor = el.bounds.top >= anchor.bounds.bottom
                val horizontallyCentered = abs(el.bounds.centerX() - screenW / 2) <= screenW * 0.25f
                (isCloseGlyph && belowAnchor) ||
                    (el.isClickable && el.text.isEmpty() && belowAnchor && horizontallyCentered &&
                        el.bounds.width() in 36..180 && el.bounds.height() in 36..180)
            }
            .minByOrNull { it.bounds.top }

        if (closeButton != null) {
            dispatchTap(closeButton.bounds.centerX().toFloat(), closeButton.bounds.centerY().toFloat())
        }
    }

    private fun triggerLevel15HardStop() {
        playSafetyAlert()
        repository.requestStopAutomation(
            status = BotStatus.STOPPED_LEVEL_15_LIMIT,
            message = "Loss recorded on Level 15",
        )
    }

    private fun triggerErrorStop(reason: String) {
        playSafetyAlert()
        repository.requestStopAutomation(
            status = BotStatus.STOPPED_UI_ERROR,
            message = reason,
        )
    }

    private fun playSafetyAlert() {
        runCatching {
            val tone = ToneGenerator(AudioManager.STREAM_ALARM, 90)
            tone.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 600)
        }
        runCatching {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vm.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 250, 120, 350), -1))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(500)
            }
        }
    }

    private fun getScreenSize(): Pair<Int, Int> {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = wm.currentWindowMetrics.bounds
            bounds.width() to bounds.height()
        } else {
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(metrics)
            metrics.widthPixels to metrics.heightPixels
        }
    }

    private suspend fun dispatchTap(x: Float, y: Float): Boolean {
        val overlay = repository.overlayBoundsOnScreen
        if (overlay != null && overlay.contains(x.toInt(), y.toInt())) {
            return false
        }
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 70L)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        return dispatchGestureSuspend(gesture)
    }

    private suspend fun dispatchSwipe(
        startX: Float,
        startY: Float,
        endX: Float,
        endY: Float,
        durationMs: Long,
    ): Boolean {
        val path = Path().apply {
            moveTo(startX, startY)
            lineTo(endX, endY)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0L, durationMs)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        return dispatchGestureSuspend(gesture)
    }

    private suspend fun dispatchGestureSuspend(gesture: GestureDescription): Boolean =
        suspendCancellableCoroutine { cont ->
            val dispatched = dispatchGesture(
                gesture,
                object : GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        if (cont.isActive) cont.resume(true)
                    }

                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        if (cont.isActive) cont.resume(false)
                    }
                },
                null,
            )
            if (!dispatched && cont.isActive) {
                cont.resume(false)
            }
        }

    private fun coroutineContextActive(): Boolean {
        return automationJob?.isActive == true && repository.automationRequested.value
    }

    companion object {
        fun isServiceEnabled(context: Context): Boolean {
            val expectedComponent = ComponentName(context, K3AccessibilityService::class.java)
            val enabledServices = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES,
            ) ?: return false
            val splitter = TextUtils.SimpleStringSplitter(':')
            splitter.setString(enabledServices)
            while (splitter.hasNext()) {
                val componentName = ComponentName.unflattenFromString(splitter.next())
                if (componentName == expectedComponent) {
                    return true
                }
            }
            return false
        }
    }
}

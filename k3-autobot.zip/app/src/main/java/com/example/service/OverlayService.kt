package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import com.example.MainActivity
import com.example.R
import com.example.data.BotConfigRepository
import com.example.model.BetTarget
import com.example.model.BotStatus
import com.example.model.BotTelemetry
import kotlin.math.abs
import kotlinx.coroutines.launch

class OverlayService : LifecycleService() {

    private lateinit var windowManager: WindowManager
    private lateinit var repository: BotConfigRepository
    private lateinit var rootView: View
    private lateinit var layoutParams: WindowManager.LayoutParams

    private lateinit var expandedContainer: View
    private lateinit var minimizedBubble: View
    private lateinit var dragHandle: View
    private lateinit var statusDot: View
    private lateinit var bubbleStatusDot: View
    private lateinit var statusText: TextView
    private lateinit var periodText: TextView
    private lateinit var levelText: TextView
    private lateinit var amountText: TextView
    private lateinit var timerText: TextView
    private lateinit var wlText: TextView
    private lateinit var bubbleLabel: TextView
    private lateinit var targetBtn: Button
    private lateinit var startStopBtn: Button
    private lateinit var minimizeBtn: ImageButton
    private lateinit var closeBtn: ImageButton

    private var isMinimized = false
    private var isViewAttached = false

    override fun onCreate() {
        super.onCreate()
        repository = BotConfigRepository.getInstance(this)
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        startAsForeground()

        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }

        setupOverlayView()
        repository.setOverlayActive(true)

        lifecycleScope.launch {
            repository.telemetry.collect { telemetry ->
                renderTelemetry(telemetry)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent?.action == ACTION_STOP) {
            repository.requestStopAutomation(BotStatus.IDLE, "Overlay closed")
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onDestroy() {
        repository.requestStopAutomation(BotStatus.IDLE, "Overlay stopped")
        repository.setOverlayActive(false)
        if (isViewAttached) {
            runCatching { windowManager.removeView(rootView) }
            isViewAttached = false
        }
        super.onDestroy()
    }

    private fun startAsForeground() {
        val channelId = getString(R.string.notification_channel_id)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW,
            )
            val nm = getSystemService(NotificationManager::class.java)
            nm?.createNotificationChannel(channel)
        }

        val launchIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(getString(R.string.notification_text))
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(launchIntent)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            ServiceCompat.startForeground(
                this,
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE,
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun setupOverlayView() {
        rootView = LayoutInflater.from(this).inflate(R.layout.overlay_floating_widget, null)

        expandedContainer = rootView.findViewById(R.id.overlay_expanded_container)
        minimizedBubble = rootView.findViewById(R.id.overlay_minimized_bubble)
        dragHandle = rootView.findViewById(R.id.overlay_drag_handle)
        statusDot = rootView.findViewById(R.id.overlay_status_dot)
        bubbleStatusDot = rootView.findViewById(R.id.bubble_status_dot)
        statusText = rootView.findViewById(R.id.overlay_status_text)
        periodText = rootView.findViewById(R.id.overlay_period_text)
        levelText = rootView.findViewById(R.id.overlay_level_text)
        amountText = rootView.findViewById(R.id.overlay_amount_text)
        timerText = rootView.findViewById(R.id.overlay_timer_text)
        wlText = rootView.findViewById(R.id.overlay_wl_text)
        bubbleLabel = rootView.findViewById(R.id.bubble_label)
        targetBtn = rootView.findViewById(R.id.btn_overlay_target)
        startStopBtn = rootView.findViewById(R.id.btn_overlay_start_stop)
        minimizeBtn = rootView.findViewById(R.id.btn_overlay_minimize)
        closeBtn = rootView.findViewById(R.id.btn_overlay_close)

        val windowType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            windowType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 180
        }

        attachDragListener(dragHandle, onTap = null)
        attachDragListener(minimizedBubble, onTap = { setMinimized(false) })

        minimizeBtn.setOnClickListener { setMinimized(true) }
        closeBtn.setOnClickListener {
            repository.requestStopAutomation(BotStatus.IDLE, "Overlay closed")
            stopSelf()
        }
        targetBtn.setOnClickListener {
            repository.toggleTargetFromOverlay()
        }
        startStopBtn.setOnClickListener {
            val current = repository.telemetry.value
            if (current.status.isRunning) {
                repository.requestStopAutomation(BotStatus.IDLE, "Stopped manually")
            } else {
                if (!K3AccessibilityService.isServiceEnabled(this)) {
                    repository.requestStopAutomation(
                        BotStatus.STOPPED_UI_ERROR,
                        "Enable Accessibility Service first",
                    )
                } else {
                    repository.requestStartAutomation()
                }
            }
        }

        rootView.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ ->
            publishOverlayBounds()
        }

        windowManager.addView(rootView, layoutParams)
        isViewAttached = true
        publishOverlayBounds()
    }

    private fun attachDragListener(target: View, onTap: (() -> Unit)?) {
        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isDragging = false

        target.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = layoutParams.x
                    initialY = layoutParams.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isDragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()
                    if (abs(dx) > touchSlop || abs(dy) > touchSlop) {
                        isDragging = true
                    }
                    if (isDragging) {
                        layoutParams.x = (initialX + dx).coerceAtLeast(0)
                        layoutParams.y = (initialY + dy).coerceAtLeast(0)
                        if (isViewAttached) {
                            windowManager.updateViewLayout(rootView, layoutParams)
                            publishOverlayBounds()
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!isDragging) {
                        onTap?.invoke()
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun setMinimized(minimized: Boolean) {
        isMinimized = minimized
        expandedContainer.visibility = if (minimized) View.GONE else View.VISIBLE
        minimizedBubble.visibility = if (minimized) View.VISIBLE else View.GONE
        rootView.post { publishOverlayBounds() }
    }

    private fun publishOverlayBounds() {
        if (!isViewAttached) return
        val loc = IntArray(2)
        rootView.getLocationOnScreen(loc)
        repository.overlayBoundsOnScreen = Rect(
            loc[0],
            loc[1],
            loc[0] + rootView.width,
            loc[1] + rootView.height,
        )
    }

    private fun renderTelemetry(t: BotTelemetry) {
        if (!isViewAttached) return

        val dotColor = when {
            t.status.isTerminalError -> Color.parseColor("#FF5252")
            t.status == BotStatus.PLACING_BET -> Color.parseColor("#FFB300")
            t.status.isRunning -> Color.parseColor("#00E676")
            else -> Color.parseColor("#64748B")
        }
        (statusDot.background as? GradientDrawable)?.setColor(dotColor)
        (bubbleStatusDot.background as? GradientDrawable)?.setColor(dotColor)

        statusText.text = if (t.statusMessage.isNotBlank() && t.status != BotStatus.IDLE) {
            "${t.status.displayLabel} • ${t.statusMessage}"
        } else {
            t.status.displayLabel
        }
        statusText.setTextColor(dotColor)

        periodText.text = t.currentPeriod.ifBlank { "---" }
        levelText.text = "Level ${t.currentLevel} / 15"
        amountText.text = "₹${t.activeAmount}"
        timerText.text = t.remainingSeconds?.let { secs ->
            val m = secs / 60
            val s = secs % 60
            String.format("Timer: %02d:%02d", m, s)
        } ?: "Timer: --:--"
        wlText.text = "W:${t.winsCount} L:${t.lossesCount}"

        bubbleLabel.text = "L${t.currentLevel} ₹${t.activeAmount}"

        targetBtn.text = t.target.label.uppercase()
        targetBtn.isEnabled = !t.status.isRunning
        targetBtn.alpha = if (t.status.isRunning) 0.55f else 1.0f
        targetBtn.setTextColor(
            if (t.target == BetTarget.BIG) Color.parseColor("#FFB300")
            else Color.parseColor("#38BDF8")
        )

        if (t.status.isRunning) {
            startStopBtn.text = getString(R.string.overlay_stop)
            startStopBtn.setBackgroundResource(R.drawable.bg_btn_stop)
        } else {
            startStopBtn.text = getString(R.string.overlay_start)
            startStopBtn.setBackgroundResource(R.drawable.bg_btn_start)
        }
    }

    companion object {
        private const val NOTIFICATION_ID = 4109
        const val ACTION_START = "com.example.action.START_OVERLAY"
        const val ACTION_STOP = "com.example.action.STOP_OVERLAY"

        fun start(context: Context) {
            val intent = Intent(context, OverlayService::class.java).apply {
                action = ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, OverlayService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }
}

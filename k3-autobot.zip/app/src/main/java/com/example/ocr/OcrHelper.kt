package com.example.ocr

import android.graphics.Bitmap
import android.graphics.Rect
import com.example.model.BetTarget
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.abs
import kotlinx.coroutines.suspendCancellableCoroutine

data class ScreenElement(
    val text: String,
    val bounds: Rect,
    val isClickable: Boolean = false,
    val isEditable: Boolean = false,
    val isCheckable: Boolean = false,
    val isChecked: Boolean = false,
    val fromOcr: Boolean = false,
)

data class OcrSnapshot(
    val fullText: String,
    val lines: List<ScreenElement>,
    val elements: List<ScreenElement>,
)

data class HistoryRowResult(
    val periodId: String,
    val outcome: BetTarget,
    val rawText: String,
)

data class AmountClickPlan(
    val baseUnit: Int,
    val multiplierChip: Int,
    val plusTaps: Int,
) {
    val totalComputed: Int get() = baseUnit * (multiplierChip + plusTaps)
}

class OcrHelper {

    private val recognizer: TextRecognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    suspend fun recognizeBitmap(bitmap: Bitmap): OcrSnapshot =
        suspendCancellableCoroutine { continuation ->
            val image = InputImage.fromBitmap(bitmap, 0)
            recognizer.process(image)
                .addOnSuccessListener { visionText ->
                    val lines = mutableListOf<ScreenElement>()
                    val tokens = mutableListOf<ScreenElement>()
                    for (block in visionText.textBlocks) {
                        for (line in block.lines) {
                            val lineBox = line.boundingBox ?: continue
                            val lineText = line.text.trim()
                            if (lineText.isNotEmpty()) {
                                lines += ScreenElement(
                                    text = lineText,
                                    bounds = Rect(lineBox),
                                    fromOcr = true,
                                )
                            }
                            for (element in line.elements) {
                                val elBox = element.boundingBox ?: continue
                                val elText = element.text.trim()
                                if (elText.isNotEmpty()) {
                                    tokens += ScreenElement(
                                        text = elText,
                                        bounds = Rect(elBox),
                                        fromOcr = true,
                                    )
                                }
                            }
                        }
                    }
                    if (continuation.isActive) {
                        continuation.resume(
                            OcrSnapshot(
                                fullText = visionText.text,
                                lines = lines,
                                elements = tokens,
                            )
                        )
                    }
                }
                .addOnFailureListener { error ->
                    if (continuation.isActive) {
                        continuation.resumeWithException(error)
                    }
                }
        }

    fun close() {
        runCatching { recognizer.close() }
    }

    companion object {
        private val PERIOD_REGEX = Regex("""\b(20\d{12,18})\b""")
        private val COMPACT_DIGITS_REGEX = Regex("""20\d{12,18}""")
        private val TIMER_COLON_REGEX = Regex("""\b([0-5]?\d)\s*:\s*([0-5]\d)\b""")
        private val TIMER_FOUR_DIGITS_REGEX = Regex("""\b([0-5]\d)\s+([0-5]\d)\b""")
        private val TOTAL_AMOUNT_REGEX = Regex(
            """total\s*amount\s*[₹rRsS$€£?\s]*([0-9,]+(?:\.[0-9]{1,2})?)""",
            RegexOption.IGNORE_CASE,
        )
        private val CURRENCY_NUMBER_REGEX = Regex(
            """[₹]\s*([0-9,]+(?:\.[0-9]{1,2})?)"""
        )

        /**
         * Extracts the active top-of-page Period ID (17-digit K3 period),
         * prioritizing elements above the "Game history" / "Period Sum Results" table.
         */
        fun extractActivePeriodId(elements: List<ScreenElement>): String? {
            val historyHeaderY = elements
                .firstOrNull { el ->
                    val lower = el.text.lowercase()
                    lower.contains("game history") ||
                        (lower.contains("period") && lower.contains("sum")) ||
                        lower == "results"
                }
                ?.bounds
                ?.top

            val topSection = if (historyHeaderY != null) {
                elements.filter { it.bounds.bottom <= historyHeaderY + 40 }
            } else {
                elements
            }

            val candidates = topSection
                .sortedBy { it.bounds.top }
                .mapNotNull { el ->
                    val compact = el.text.replace(" ", "")
                    PERIOD_REGEX.find(el.text)?.groupValues?.get(1)
                        ?: COMPACT_DIGITS_REGEX.find(compact)?.value
                }
            if (candidates.isNotEmpty()) return candidates.first()

            return elements
                .sortedBy { it.bounds.top }
                .firstNotNullOfOrNull { el ->
                    PERIOD_REGEX.find(el.text)?.groupValues?.get(1)
                }
        }

        fun extractPeriodId(texts: List<String>): String? {
            for (text in texts) {
                val match = PERIOD_REGEX.find(text)
                if (match != null) return match.groupValues[1]
            }
            return null
        }

        /**
         * Extracts remaining countdown seconds (`MM : SS`).
         * Handles both single-string timers (`00:45`) and split WebView digit boxes (`0`, `0`, `:`, `4`, `5`).
         */
        fun extractRemainingSeconds(elements: List<ScreenElement>): Int? {
            // 1. Direct regex match near "Time remaining" or top half
            val sorted = elements.sortedBy { it.bounds.top }
            for (el in sorted) {
                val match = TIMER_COLON_REGEX.find(el.text)
                if (match != null) {
                    val mins = match.groupValues[1].toIntOrNull() ?: continue
                    val secs = match.groupValues[2].toIntOrNull() ?: continue
                    if (mins in 0..5 && secs in 0..59) {
                        return mins * 60 + secs
                    }
                }
            }

            // 2. Group horizontally aligned elements near "Time remaining"
            val timeAnchor = sorted.firstOrNull {
                it.text.contains("time remaining", ignoreCase = true) ||
                    it.text.equals("time", ignoreCase = true)
            }
            val searchPool = if (timeAnchor != null) {
                sorted.filter {
                    it.bounds.top >= timeAnchor.bounds.top - 40 &&
                        it.bounds.bottom <= timeAnchor.bounds.bottom + 260
                }
            } else {
                sorted
            }

            val rows = groupIntoRows(searchPool, rowTolerancePx = 36)
            for (row in rows) {
                val joined = row.sortedBy { it.bounds.left }
                    .joinToString(" ") { it.text.trim() }
                val compact = joined.replace(" ", "")
                val colonMatch = TIMER_COLON_REGEX.find(compact)
                if (colonMatch != null) {
                    val mins = colonMatch.groupValues[1].toIntOrNull() ?: continue
                    val secs = colonMatch.groupValues[2].toIntOrNull() ?: continue
                    if (mins in 0..5 && secs in 0..59) {
                        return mins * 60 + secs
                    }
                }
                val spacedMatch = TIMER_FOUR_DIGITS_REGEX.find(joined)
                if (spacedMatch != null && timeAnchor != null) {
                    val mins = spacedMatch.groupValues[1].toIntOrNull() ?: continue
                    val secs = spacedMatch.groupValues[2].toIntOrNull() ?: continue
                    if (mins in 0..5 && secs in 0..59) {
                        return mins * 60 + secs
                    }
                }
                // Handle 4 isolated single digits like "0 0 4 5"
                val digitsOnly = compact.filter { it.isDigit() }
                if (timeAnchor != null && digitsOnly.length == 4) {
                    val mins = digitsOnly.substring(0, 2).toIntOrNull() ?: continue
                    val secs = digitsOnly.substring(2, 4).toIntOrNull() ?: continue
                    if (mins in 0..1 && secs in 0..59) {
                        return mins * 60 + secs
                    }
                }
            }

            return null
        }

        fun extractTotalAmountRupees(elements: List<ScreenElement>): Double? {
            // Check single elements first
            for (el in elements) {
                TOTAL_AMOUNT_REGEX.find(el.text)?.let { match ->
                    val parsed = match.groupValues[1].replace(",", "").toDoubleOrNull()
                    if (parsed != null) return parsed
                }
            }
            // Check horizontally grouped rows containing "Total amount"
            for (row in groupIntoRows(elements, rowTolerancePx = 36)) {
                val rowText = row.sortedBy { it.bounds.left }.joinToString(" ") { it.text }
                if (rowText.contains("total amount", ignoreCase = true)) {
                    TOTAL_AMOUNT_REGEX.find(rowText)?.let { match ->
                        val parsed = match.groupValues[1].replace(",", "").toDoubleOrNull()
                        if (parsed != null) return parsed
                    }
                    CURRENCY_NUMBER_REGEX.find(rowText)?.let { match ->
                        val parsed = match.groupValues[1].replace(",", "").toDoubleOrNull()
                        if (parsed != null) return parsed
                    }
                }
            }
            return null
        }

        /**
         * Inspects the first data row directly beneath the `Period | Sum | Results` header.
         */
        fun parseHistoryTopRow(
            elements: List<ScreenElement>,
            expectedPeriodId: String,
        ): HistoryRowResult? {
            if (expectedPeriodId.isBlank()) return null

            val headerY = findHistoryHeaderBottom(elements) ?: return null
            val belowHeader = elements
                .filter { it.bounds.top >= headerY - 8 }
                .sortedBy { it.bounds.top }

            val rows = groupIntoRows(belowHeader, rowTolerancePx = 42)
            val firstDataRow = rows.firstOrNull { row ->
                val text = row.joinToString(" ") { it.text }
                PERIOD_REGEX.containsMatchIn(text) ||
                    text.contains(expectedPeriodId.takeLast(6))
            } ?: return null

            val rowText = firstDataRow.sortedBy { it.bounds.left }.joinToString(" ") { it.text }
            val detectedPeriod = PERIOD_REGEX.find(rowText.replace(" ", ""))?.groupValues?.get(1)
                ?: PERIOD_REGEX.find(rowText)?.groupValues?.get(1)

            val periodMatches = if (detectedPeriod != null) {
                detectedPeriod == expectedPeriodId
            } else {
                rowText.replace(" ", "").contains(expectedPeriodId)
            }
            if (!periodMatches) return null

            val lower = rowText.lowercase()
            val hasBig = Regex("""\bbig\b""").containsMatchIn(lower)
            val hasSmall = Regex("""\bsmall\b""").containsMatchIn(lower)
            val outcome = when {
                hasBig && !hasSmall -> BetTarget.BIG
                hasSmall && !hasBig -> BetTarget.SMALL
                else -> return null
            }

            return HistoryRowResult(
                periodId = expectedPeriodId,
                outcome = outcome,
                rawText = rowText,
            )
        }

        fun findHistoryHeaderBottom(elements: List<ScreenElement>): Int? {
            val rows = groupIntoRows(elements, rowTolerancePx = 36)
            for (row in rows.sortedBy { it.minOf { el -> el.bounds.top } }) {
                val rowText = row.joinToString(" ") { it.text }.lowercase()
                if (rowText.contains("period") && (rowText.contains("sum") || rowText.contains("result"))) {
                    return row.maxOf { it.bounds.bottom }
                }
            }
            return null
        }

        fun groupIntoRows(
            elements: List<ScreenElement>,
            rowTolerancePx: Int = 36,
        ): List<List<ScreenElement>> {
            if (elements.isEmpty()) return emptyList()
            val sorted = elements.sortedBy { it.bounds.centerY() }
            val rows = mutableListOf<MutableList<ScreenElement>>()
            for (el in sorted) {
                val targetRow = rows.lastOrNull()?.takeIf { row ->
                    val avgY = row.map { it.bounds.centerY() }.average()
                    abs(el.bounds.centerY() - avgY) <= rowTolerancePx
                }
                if (targetRow != null) {
                    targetRow += el
                } else {
                    rows += mutableListOf(el)
                }
            }
            return rows
        }

        /**
         * Computes an exact combination of Base Units (1, 10, 100, 1000),
         * Multiplier chips (1, 5, 10, 20, 50, 100), and `+` taps to hit targetAmount
         * when direct ACTION_SET_TEXT on the WebView input fails.
         */
        fun computeAmountClickPlan(targetAmount: Int): AmountClickPlan {
            val safeTarget = targetAmount.coerceAtLeast(1)
            val baseUnits = listOf(1000, 100, 10, 1)
            val multipliers = listOf(100, 50, 20, 10, 5, 1)

            // Prefer exact zero-tap combinations first
            for (base in baseUnits) {
                if (safeTarget % base == 0) {
                    val qty = safeTarget / base
                    if (qty in multipliers) {
                        return AmountClickPlan(baseUnit = base, multiplierChip = qty, plusTaps = 0)
                    }
                }
            }

            // Otherwise pick the largest divisible base unit and fewest '+' taps
            var bestPlan = AmountClickPlan(baseUnit = 1, multiplierChip = 1, plusTaps = safeTarget - 1)
            for (base in baseUnits) {
                if (safeTarget % base == 0) {
                    val qty = safeTarget / base
                    val chip = multipliers.filter { it <= qty }.maxOrNull() ?: 1
                    val taps = qty - chip
                    if (taps < bestPlan.plusTaps) {
                        bestPlan = AmountClickPlan(baseUnit = base, multiplierChip = chip, plusTaps = taps)
                    }
                }
            }
            return bestPlan
        }
    }
}

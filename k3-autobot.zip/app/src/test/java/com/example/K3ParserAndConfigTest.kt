package com.example

import android.content.Context
import android.graphics.Rect
import androidx.test.core.app.ApplicationProvider
import com.example.data.BotConfigRepository
import com.example.model.BetTarget
import com.example.model.BotConfig
import com.example.ocr.OcrHelper
import com.example.ocr.ScreenElement
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class K3ParserAndConfigTest {

    @Test
    fun `extractActivePeriodId prioritizes top section above Game history`() {
        val elements = listOf(
            ScreenElement("Period", Rect(40, 120, 200, 160)),
            ScreenElement("20261114101010580", Rect(40, 170, 420, 220)),
            ScreenElement("Time remaining", Rect(600, 120, 900, 160)),
            ScreenElement("Game history", Rect(40, 980, 340, 1030)),
            ScreenElement("Period", Rect(40, 1050, 200, 1090)),
            ScreenElement("Sum", Rect(400, 1050, 520, 1090)),
            ScreenElement("Results", Rect(720, 1050, 920, 1090)),
            ScreenElement("20261114101010579", Rect(40, 1120, 420, 1170)),
        )

        val period = OcrHelper.extractActivePeriodId(elements)
        assertEquals("20261114101010580", period)
    }

    @Test
    fun `extractRemainingSeconds parses both single string and split digit boxes`() {
        val singleString = listOf(
            ScreenElement("Time remaining", Rect(560, 120, 900, 160)),
            ScreenElement("00:42", Rect(620, 175, 860, 230)),
        )
        assertEquals(42, OcrHelper.extractRemainingSeconds(singleString))

        val splitBoxes = listOf(
            ScreenElement("Time remaining", Rect(560, 120, 900, 160)),
            ScreenElement("0", Rect(600, 180, 640, 230)),
            ScreenElement("0", Rect(650, 180, 690, 230)),
            ScreenElement(":", Rect(700, 180, 720, 230)),
            ScreenElement("0", Rect(730, 180, 770, 230)),
            ScreenElement("9", Rect(780, 180, 820, 230)),
        )
        assertEquals(9, OcrHelper.extractRemainingSeconds(splitBoxes))
    }

    @Test
    fun `extractTotalAmountRupees parses currency strings accurately`() {
        val elements = listOf(
            ScreenElement("Cancel", Rect(0, 1800, 320, 1920)),
            ScreenElement("Total amount ₹1,250.00", Rect(320, 1800, 1080, 1920)),
        )
        val parsed = OcrHelper.extractTotalAmountRupees(elements)
        assertNotNull(parsed)
        assertEquals(1250.0, parsed!!, 0.001)
    }

    @Test
    fun `parseHistoryTopRow matches exact period and extracts outcome`() {
        val elements = listOf(
            ScreenElement("Period", Rect(40, 1050, 220, 1090)),
            ScreenElement("Sum", Rect(420, 1050, 540, 1090)),
            ScreenElement("Results", Rect(740, 1050, 920, 1090)),
            ScreenElement("20261114101010580", Rect(40, 1130, 400, 1180)),
            ScreenElement("14", Rect(440, 1130, 500, 1180)),
            ScreenElement("Big", Rect(760, 1130, 860, 1180)),
            ScreenElement("20261114101010579", Rect(40, 1220, 400, 1270)),
            ScreenElement("7", Rect(440, 1220, 500, 1270)),
            ScreenElement("Small", Rect(760, 1220, 880, 1270)),
        )

        val match = OcrHelper.parseHistoryTopRow(elements, "20261114101010580")
        assertNotNull(match)
        assertEquals(BetTarget.BIG, match!!.outcome)

        val mismatch = OcrHelper.parseHistoryTopRow(elements, "20261114101010579")
        assertNull(mismatch)
    }

    @Test
    fun `computeAmountClickPlan produces exact amount combinations`() {
        val p1 = OcrHelper.computeAmountClickPlan(500)
        assertEquals(500, p1.totalComputed)
        assertEquals(0, p1.plusTaps)

        val p2 = OcrHelper.computeAmountClickPlan(150)
        assertEquals(150, p2.totalComputed)
        assertEquals(10, p2.baseUnit)
        assertEquals(10, p2.multiplierChip)
        assertEquals(5, p2.plusTaps)

        val p3 = OcrHelper.computeAmountClickPlan(25)
        assertEquals(25, p3.totalComputed)
    }

    @Test
    fun `BotConfigRepository persists 15 custom levels and target`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repo = BotConfigRepository.getInstance(context)
        val customLevels = List(15) { (it + 1) * 15 }
        repo.saveConfig(
            BotConfig(
                target = BetTarget.SMALL,
                levelAmounts = customLevels,
                quickFillBase = 15,
                quickFillMultiplier = 3,
            )
        )

        val saved = repo.config.value
        assertEquals(BetTarget.SMALL, saved.target)
        assertEquals(15, saved.levelAmounts.size)
        assertEquals(225, saved.amountForLevel(15))
    }
}
